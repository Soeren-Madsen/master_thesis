function mes = measure(x)
    %two sine wave
    mes = x(1)-x(3)-x(6);
    
end