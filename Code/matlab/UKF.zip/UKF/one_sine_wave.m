clear; clc;
format compact;
omega = 1;
H = 100;
acc=0;
%One sine wave
A = [0 1 0 0; 0 0 0 0; 0 0 0 omega; 0 0 -omega 0];