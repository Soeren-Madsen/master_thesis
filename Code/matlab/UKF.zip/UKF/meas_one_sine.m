function mes = measure(x)
    %One sine wave
    mes = x(1)-x(3);
    
end