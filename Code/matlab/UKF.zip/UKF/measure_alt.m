function res = measure(x)
    res = x(1)
end